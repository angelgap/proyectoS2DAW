import { Routes, Route, Navigate } from "react-router-dom";
import Bienvenida from "./pages/Bienvenida";
import Home from "./pages/Home";
import Search from "./pages/Search";
import { useUsuario } from "./contexts/UsuarioContext";

export default function App() {
  const { usuario } = useUsuario();

  return (
    <Routes>
      <Route path="/" element={<Bienvenida />} />
      <Route path="/home" element={usuario ? <Home /> : <Navigate to="/" />} />
      <Route path="/search" element={usuario ? <Search /> : <Navigate to="/" />} />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}
