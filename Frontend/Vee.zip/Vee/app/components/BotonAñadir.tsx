interface Props {
  onClick: () => void;
}

export default function FloatingButton({ onClick }: Props) {
  return (
    <button
      onClick={onClick}
      className="w-12 h-12 rounded-full bg-yellow-400 text-black text-2xl fixed bottom-6 right-6 shadow-md"
    >
      +
    </button>
  );
}
