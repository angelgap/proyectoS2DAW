// components/ComentarioCard.tsx
import type { Comentario } from "../types/Comentario";

interface Props {
  comentario: Comentario;
}

export default function ComentarioCard({ comentario }: Props) {
  return (
    <div className="border-t mt-2 pt-2 text-sm">
      <p className="font-medium mb-1">{comentario.usuarioNombre}</p>

      {/* Imagen del comentario */}
      {comentario.imagen?.url && (
        <img
          src={comentario.imagen.url}
          alt="imagen del comentario"
          className="w-24 h-auto object-cover my-2 rounded"
        />
      )}

      {/* Contenido del comentario (puede venir con HTML si usaste Quill) */}
      <div dangerouslySetInnerHTML={{ __html: comentario.texto }} />
    </div>
  );
}
