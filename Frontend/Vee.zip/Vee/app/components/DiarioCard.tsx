// components/DiarioCard.tsx
import type { Diario } from "../types/Diario";
import ComentarioCard from "./ComentarioCard";

interface Props {
  diario: Diario;
  onEditar?: () => void;
  onComentar?: () => void;
}

export default function DiarioCard({ diario, onEditar, onComentar }: Props) {
  return (
    <div className="bg-white shadow rounded p-4">
      <h2 className="text-lg font-semibold">{diario.titulo}</h2>
      <div
        className="text-sm mt-2"
        dangerouslySetInnerHTML={{ __html: diario.contenido }}
      />

      {/* Mostrar imágenes del diario */}
      {diario.imagenes?.map((img) => (
        <img
          key={img.id}
          src={img.url}
          alt="imagen del diario"
          className="w-full h-auto mt-2 rounded"
        />
      ))}

      {/* Botones de acción */}
      <div className="mt-4 flex gap-2">
        {onComentar && (
          <button
            onClick={onComentar}
            className="bg-yellow-400 hover:bg-yellow-500 text-white px-4 py-1 rounded"
          >
            Comentar
          </button>
        )}
        {onEditar && (
          <button
            onClick={onEditar}
            className="bg-gray-300 hover:bg-gray-400 px-4 py-1 rounded"
          >
            Editar
          </button>
        )}
      </div>

      {/* Comentarios del diario */}
      <div className="mt-4 space-y-2">
        {diario.comentarios.map((comentario) => (
          <ComentarioCard key={comentario.id} comentario={comentario} />
        ))}
      </div>
    </div>
  );
}
