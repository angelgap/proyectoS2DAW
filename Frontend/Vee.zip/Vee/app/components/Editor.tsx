import { useState } from "react";
import "react-quill/dist/quill.snow.css";
import { crearDiario, editarDiario, comentar } from "../services/api";

// 🔁 Import dinámico para evitar error en SSR (document is not defined)
const ReactQuill =
  typeof window === "undefined" ? () => null : require("react-quill");

interface EditorProps {
  modo: "crear" | "editar" | "comentar";
  usuarioId: number;
  diarioId?: number;
  tituloInicial?: string;
  contenidoInicial?: string;
  onSuccess: () => void;
}

export default function Editor({
  modo,
  usuarioId,
  diarioId,
  tituloInicial = "",
  contenidoInicial = "",
  onSuccess,
}: EditorProps) {
  const [titulo, setTitulo] = useState(tituloInicial);
  const [contenido, setContenido] = useState(contenidoInicial);
  const [imagen, setImagen] = useState<File | null>(null);
  const [cargando, setCargando] = useState(false);

  const manejarEnvio = async () => {
    try {
      setCargando(true);

      const formData = new FormData();
      formData.append("contenido", contenido);
      if (imagen) formData.append("imagen", imagen);

      if (modo === "crear" && !titulo.trim() && !contenido.trim()) {
        alert("Completa al menos el título o el contenido.");
        setCargando(false);
        return;
      }

      if (modo === "crear") {
        formData.append("titulo", titulo);
        formData.append("usuarioId", usuarioId.toString());
        await crearDiario(formData);
      }

      if (modo === "editar" && diarioId) {
        formData.append("titulo", titulo);
        await editarDiario(diarioId, formData);
      }

      if (modo === "comentar" && diarioId) {
        formData.append("usuarioId", usuarioId.toString());
        formData.append("diarioId", diarioId.toString());
        await comentar(formData);
      }

      onSuccess();
      setTitulo("");
      setContenido("");
      setImagen(null);
    } catch (error) {
      console.error("Error al enviar:", error);
    } finally {
      setCargando(false);
    }
  };

  return (
    <div className="space-y-4">
      {modo !== "comentar" && (
        <input
          type="text"
          className="w-full border p-2 rounded"
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
          placeholder="Título"
        />
      )}

      {/* ✅ Solo renderiza si ReactQuill está disponible */}
      {ReactQuill && (
        <ReactQuill
          theme="snow"
          value={contenido}
          onChange={setContenido}
          className="bg-white"
          placeholder="¿En qué estás pensando?"
        />
      )}

      <input type="file" onChange={(e) => setImagen(e.target.files?.[0] || null)} />

      <button
        onClick={manejarEnvio}
        disabled={cargando}
        className="bg-yellow-400 hover:bg-yellow-500 text-white font-bold px-4 py-2 rounded"
      >
        {modo === "crear" && "Publicar"}
        {modo === "editar" && "Guardar cambios"}
        {modo === "comentar" && "Comentar"}
      </button>
    </div>
  );
}
