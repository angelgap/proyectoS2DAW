import { useEffect, useState } from "react";
import DiarioCard from "../components/DiarioCard";
import Editor from "../components/Editor";
import BotonAñadir from "../components/BotonAñadir";
import type { Diario } from "../types/Diario";
import { getDiariosUsuario } from "../services/api";
import { useUsuario } from "../contexts/UsuarioContext";

export default function Home() {
  const { usuario } = useUsuario();
  const [diarios, setDiarios] = useState<Diario[]>([]);
  const [modoEditor, setModoEditor] = useState<"crear" | "editar" | "comentar">("crear");
  const [diarioAEditar, setDiarioAEditar] = useState<Diario | null>(null);
  const [mostrarEditor, setMostrarEditor] = useState(false);

  const cargarDiarios = async () => {
    try {
      if (!usuario) return;
      const res = await getDiariosUsuario(usuario.id);
      setDiarios(res.data);
    } catch (err) {
      console.error("Error al cargar diarios:", err);
    }
  };

  useEffect(() => {
    if (usuario) {
      cargarDiarios();
    }
  }, [usuario]);

  const abrirEditorCrear = () => {
    setModoEditor("crear");
    setDiarioAEditar(null);
    setMostrarEditor(true);
  };

  const abrirEditorEditar = (diario: Diario) => {
    setModoEditor("editar");
    setDiarioAEditar(diario);
    setMostrarEditor(true);
  };

  const abrirEditorComentar = (diario: Diario) => {
    setModoEditor("comentar");
    setDiarioAEditar(diario);
    setMostrarEditor(true);
  };

  if (!usuario) return <p className="p-4">Debes iniciar sesión para ver tus diarios.</p>;

  return (
    <div className="p-4">
      {/* 🖥️ Editor fijo en escritorio */}
      <div className="hidden md:block mb-4">
        <Editor modo="crear" usuarioId={usuario.id} onSuccess={cargarDiarios} />
      </div>

      {/* 📚 Lista de diarios */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {diarios.map((diario) => (
          <DiarioCard
            key={diario.id}
            diario={diario}
            onEditar={() => abrirEditorEditar(diario)}
            onComentar={() => abrirEditorComentar(diario)}
          />
        ))}
      </div>

      {/* 📱 Botón + solo en móvil */}
      <div className="block md:hidden">
        <BotonAñadir onClick={abrirEditorCrear} />
      </div>

      {/* 🪟 Modal editor para móvil */}
      {mostrarEditor && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-lg p-4">
            <Editor
              modo={modoEditor}
              usuarioId={usuario.id}
              diarioId={diarioAEditar?.id}
              tituloInicial={diarioAEditar?.titulo}
              contenidoInicial={diarioAEditar?.contenido}
              onSuccess={() => {
                cargarDiarios();
                setMostrarEditor(false);
                setDiarioAEditar(null);
              }}
            />
            <button
              onClick={() => setMostrarEditor(false)}
              className="mt-2 text-sm text-gray-600 hover:underline"
            >
              Cerrar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
