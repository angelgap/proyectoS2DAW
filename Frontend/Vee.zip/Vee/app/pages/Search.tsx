import { useEffect, useState } from "react";
import { buscarUsuarios, getUsuarios, getDiariosUsuario } from "../services/api";
import type { Usuario } from "../types/Usuario";
import type { Diario } from "../types/Diario";
import DiarioCard from "../components/DiarioCard";
import Editor from "../components/Editor";
import { useUsuario } from "../contexts/UsuarioContext";

export default function Search() {
  const { usuario } = useUsuario();
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [diariosPorUsuario, setDiariosPorUsuario] = useState<Record<number, Diario[]>>({});
  const [busqueda, setBusqueda] = useState("");
  const [diarioAComentar, setDiarioAComentar] = useState<Diario | null>(null);

  const cargarUsuarios = async () => {
    const res = await getUsuarios();
    setUsuarios(res.data);
    cargarDiariosPorUsuario(res.data);
  };

  const cargarDiariosPorUsuario = async (usuarios: Usuario[]) => {
    const diariosMap: Record<number, Diario[]> = {};
    for (const usuario of usuarios) {
      const res = await getDiariosUsuario(usuario.id);
      diariosMap[usuario.id] = res.data;
    }
    setDiariosPorUsuario(diariosMap);
  };

  const buscar = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await buscarUsuarios(busqueda);
    setUsuarios(res.data);
    cargarDiariosPorUsuario(res.data);
  };

  useEffect(() => {
    cargarUsuarios();
  }, []);

  if (!usuario) return <p className="p-4">Debes iniciar sesión para buscar usuarios.</p>;

  return (
    <div className="p-4">
      {/* 🔍 Buscador */}
      <form onSubmit={buscar} className="mb-6">
        <input
          value={busqueda}
          onChange={(e) => setBusqueda(e.target.value)}
          placeholder="Buscar usuario por nombre"
          className="w-full p-2 border rounded"
        />
      </form>

      {/* 👥 Usuarios y diarios */}
      <div className="space-y-8">
        {usuarios.map((usuario) => (
          <div key={usuario.id} className="bg-gray-100 p-4 rounded shadow">
            <h2 className="text-xl font-semibold mb-3 text-center">{usuario.nombre}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {diariosPorUsuario[usuario.id]?.map((diario) => (
                <DiarioCard
                  key={diario.id}
                  diario={diario}
                  onComentar={() => setDiarioAComentar(diario)}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* 💬 Editor flotante (modal para comentar) */}
      {diarioAComentar && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-lg p-4">
            <Editor
              modo="comentar"
              usuarioId={usuario.id}
              diarioId={diarioAComentar.id}
              onSuccess={() => {
                setDiarioAComentar(null);
                cargarUsuarios();
              }}
            />
            <button
              onClick={() => setDiarioAComentar(null)}
              className="mt-2 text-sm text-gray-600 hover:underline"
            >
              Cerrar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
