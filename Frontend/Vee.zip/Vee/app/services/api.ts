import axios from "axios";

const API_BASE = "http://localhost:8080";

// USUARIOS
export const getUsuarios = () => axios.get(`${API_BASE}/usuarios`);

export const buscarUsuarios = (nombre: string) =>
  axios.get(`${API_BASE}/usuarios/nombre`, {
    params: { nombre },
  });

// DIARIOS
export const getDiariosUsuario = (usuarioId: number) =>
  axios.get(`${API_BASE}/diarios/usuario/${usuarioId}`);

// 🆕 Crear diario con imagen
export const crearDiario = (formData: FormData) =>
  axios.post(`${API_BASE}/diarios`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });

// 🆕 Editar diario con imagen
export const editarDiario = (diarioId: number, formData: FormData) =>
  axios.put(`${API_BASE}/diarios/${diarioId}`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });

// 🆕 Comentar diario con imagen
export const comentar = (formData: FormData) =>
  axios.post(`${API_BASE}/comentarios`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
