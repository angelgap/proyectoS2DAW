export interface Comentario {
  id: number;
  texto: string;
  usuarioId: number;
  diarioId: number;
  usuarioNombre: string;
  imagen?: { id: number; url: string };
}

