import type { Comentario } from "./Comentario";

export interface Diario {
  id: number;
  titulo: string;
  contenido: string;
  fecha: string;
  usuarioId: number;
  comentarios: Comentario[]; // Ya no dará error
  imagenes: Imagen[];
}

export interface Imagen {
  id: number;
  url: string;
}
